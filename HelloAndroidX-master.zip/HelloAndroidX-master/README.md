# HelloAndroidX

###### Author: Francisco Martinez

Hello Android example with XML Layouts applying the inflation concept 
